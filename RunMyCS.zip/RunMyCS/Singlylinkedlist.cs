using System;

// Define the Node class for our linked list
public class Node
{
    public int Data;
    public Node Next;

    public Node(int data)
    {
        Data = data;
        Next = null;
    }
}

public class SinglyLinkedList
{
    // A function to reverse the linked list
    public static Node ReverseList(Node head)
    {
        // Pointers to keep track of the previous, current, and next nodes
        Node previous = null;
        Node current = head;
        Node next = null;

        // Iterate through the list
        while (current != null)
        {
            // Store the next node before we change the current node's next pointer
            next = current.Next;

            // Reverse the pointer of the current node
            current.Next = previous;

            // Move the pointers one step forward
            previous = current;
            current = next;
        }

        // 'previous' is now the new head of the reversed list
        return previous;
    }

    public static void Main(string[] args)
    {
        // Create a sample linked list: 1 -> 2 -> 3 -> 4
        Node head = new Node(1);
        head.Next = new Node(2);
        head.Next.Next = new Node(3);
        head.Next.Next.Next = new Node(4);

        Console.WriteLine("Original List:");
        PrintList(head); // Should print: 1 -> 2 -> 3 -> 4 -> null

        // Reverse the list and get the new head
        Node newHead = ReverseList(head);

        Console.WriteLine("\nReversed List:");
        PrintList(newHead); // Should print: 4 -> 3 -> 2 -> 1 -> null
    }

    // Helper function to print the linked list
    public static void PrintList(Node head)
    {
        Node temp = head;
        while (temp != null)
        {
            Console.Write(temp.Data + " -> ");
            temp = temp.Next;
        }
        Console.WriteLine("null");
    }
}
